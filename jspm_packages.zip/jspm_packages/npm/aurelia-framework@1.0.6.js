define(["npm:aurelia-framework@1.0.6/aurelia-framework"], function(main) {
  return main;
});