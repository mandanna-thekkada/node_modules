define(["npm:aurelia-router@1.0.6/aurelia-router"], function(main) {
  return main;
});