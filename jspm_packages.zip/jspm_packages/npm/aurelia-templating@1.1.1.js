define(["npm:aurelia-templating@1.1.1/aurelia-templating"], function(main) {
  return main;
});