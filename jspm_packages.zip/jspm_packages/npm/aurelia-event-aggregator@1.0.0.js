define(["npm:aurelia-event-aggregator@1.0.0/aurelia-event-aggregator"], function(main) {
  return main;
});