define(["npm:aurelia-task-queue@1.1.0/aurelia-task-queue"], function(main) {
  return main;
});