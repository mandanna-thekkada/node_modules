define(["npm:aurelia-animator-css@1.0.1/aurelia-animator-css"], function(main) {
  return main;
});