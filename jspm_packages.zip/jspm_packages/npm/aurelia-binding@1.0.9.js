define(["npm:aurelia-binding@1.0.9/aurelia-binding"], function(main) {
  return main;
});