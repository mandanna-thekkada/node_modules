define(["npm:aurelia-history@1.0.0/aurelia-history"], function(main) {
  return main;
});