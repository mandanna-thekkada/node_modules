/* */ 
define( function() {
	return ( /\?/ );
} );
