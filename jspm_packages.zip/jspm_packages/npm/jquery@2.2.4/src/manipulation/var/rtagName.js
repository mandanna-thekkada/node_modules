/* */ 
define( function() {
	return ( /<([\w:-]+)/ );
} );
