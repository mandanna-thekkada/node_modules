define(["npm:jquery@2.2.4/dist/jquery.js"], function(main) {
  return main;
});