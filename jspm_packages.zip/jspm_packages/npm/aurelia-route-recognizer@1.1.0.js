define(["npm:aurelia-route-recognizer@1.1.0/aurelia-route-recognizer"], function(main) {
  return main;
});