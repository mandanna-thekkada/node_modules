define(["npm:aurelia-pal-browser@1.0.0/aurelia-pal-browser"], function(main) {
  return main;
});